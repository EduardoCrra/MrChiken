<?php

class lbValidator{
	function create($config){
	}
}

?>